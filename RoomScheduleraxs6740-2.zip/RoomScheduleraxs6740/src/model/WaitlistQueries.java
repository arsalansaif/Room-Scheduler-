package model;

import db.DBConnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class WaitlistQueries {

    public static List<WaitlistEntry> getWaitlistByDate(Date date) throws Exception {
        List<WaitlistEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM waiting_list WHERE date = ? ORDER BY date, timestamp");
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String facultyRS = rs.getString("faculty");
                Date dateRS = rs.getDate("date");
                int seatsRS = rs.getInt("seats");
                Timestamp timestampRS = rs.getTimestamp("timestamp");
                list.add(new WaitlistEntry(facultyRS, dateRS, seatsRS, timestampRS));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static List<WaitlistEntry> getWaitlistByFaculty(String faculty) throws Exception {
        List<WaitlistEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM waiting_list WHERE faculty=? ORDER BY date, timestamp");
            ps.setString(1, faculty);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String facultyRS = rs.getString("faculty");
                Date dateRS = rs.getDate("date");
                int seatsRS = rs.getInt("seats");
                Timestamp timestampRS = rs.getTimestamp("timestamp");
                list.add(new WaitlistEntry(facultyRS, dateRS, seatsRS, timestampRS));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static List<WaitlistEntry> getWaitlist() throws Exception {
        List<WaitlistEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM waiting_list ORDER BY date, timestamp");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String facultyRS = rs.getString("faculty");
                Date dateRS = rs.getDate("date");
                int seatsRS = rs.getInt("seats");
                Timestamp timestampRS = rs.getTimestamp("timestamp");
                list.add(new WaitlistEntry(facultyRS, dateRS, seatsRS, timestampRS));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static void addWaitlistEntry(WaitlistEntry waitlist) throws Exception {
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("INSERT INTO waiting_list (faculty, date, seats, timestamp) VALUES (?, ?, ?, ?)");
            ps.setString(1, waitlist.getFaculty());
            ps.setDate(2, waitlist.getDate());
            ps.setInt(3, waitlist.getSeats());
            ps.setTimestamp(4, waitlist.getTimestamp());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static void deleteWaitlistEntry(WaitlistEntry waitlist) throws Exception {
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("DELETE FROM waiting_list WHERE faculty= ? AND date=?");
            ps.setString(1, waitlist.getFaculty());
            ps.setDate(2, waitlist.getDate());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

}
