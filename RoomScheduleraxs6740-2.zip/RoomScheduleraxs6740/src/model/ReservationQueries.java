package model;

import db.DBConnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ReservationQueries {

    public static List<ReservationEntry> getReservationsByDate(Date date) throws Exception {
        List<ReservationEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM reservation WHERE date = ? ORDER BY timestamp");
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String facultyRS = rs.getString("faculty");
                String roomRS = rs.getString("room");
                Date dateRS = rs.getDate("date");
                int seatsRS = rs.getInt("seats");
                Timestamp timestampRS = rs.getTimestamp("timestamp");
                list.add(new ReservationEntry(facultyRS, roomRS, dateRS, seatsRS, timestampRS));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static List<ReservationEntry> getReservationsByRoom(String room) throws Exception {
        List<ReservationEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM reservation WHERE room = ? ORDER BY timestamp");
            ps.setString(1, room);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String facultyRS = rs.getString("faculty");
                String roomRS = rs.getString("room");
                Date dateRS = rs.getDate("date");
                int seatsRS = rs.getInt("seats");
                Timestamp timestampRS = rs.getTimestamp("timestamp");
                list.add(new ReservationEntry(facultyRS, roomRS, dateRS, seatsRS, timestampRS));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static void addReservationEntry(ReservationEntry reservation) throws Exception {
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("INSERT INTO reservation (faculty, room, date, seats, timestamp) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, reservation.getFaculty());
            ps.setString(2, reservation.getRoom());
            ps.setDate(3, reservation.getDate());
            ps.setInt(4, reservation.getSeats());
            ps.setTimestamp(5, reservation.getTimestamp());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static List<ReservationEntry> getReservationsByFaculty(String faculty) throws Exception {
        List<ReservationEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM reservation WHERE faculty = ? ORDER BY timestamp");
            ps.setString(1, faculty);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String facultyRS = rs.getString("faculty");
                String roomRS = rs.getString("room");
                Date dateRS = rs.getDate("date");
                int seatsRS = rs.getInt("seats");
                Timestamp timestampRS = rs.getTimestamp("timestamp");
                list.add(new ReservationEntry(facultyRS, roomRS, dateRS, seatsRS, timestampRS));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static void deleteReservation(ReservationEntry reservation) throws Exception {
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("DELETE FROM reservation WHERE faculty= ? AND room=? AND date=?");
            ps.setString(1, reservation.getFaculty());
            ps.setString(2, reservation.getRoom());
            ps.setDate(3, reservation.getDate());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }
}
