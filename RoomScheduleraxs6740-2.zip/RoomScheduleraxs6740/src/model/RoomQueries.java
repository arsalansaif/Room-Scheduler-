package model;

import db.DBConnection;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomQueries {

    public static List<RoomEntry> getAllRooms() throws Exception {
        List<RoomEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM room ORDER BY seats");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new RoomEntry(rs.getString("name"), rs.getInt("seats")));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static List<RoomEntry> getAllPossibleRooms(Date date) throws Exception {
        List<RoomEntry> list = new ArrayList<>();
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM room WHERE name NOT IN (SELECT room FROM reservation WHERE date=?) ORDER BY seats");
            ps.setDate(1, date);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new RoomEntry(rs.getString("name"), rs.getInt("seats")));
            }
            rs.close();
            ps.close();
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static void addRoom(RoomEntry room) throws Exception {
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("INSERT INTO room (name, seats) VALUES (?, ?)");
            ps.setString(1, room.getName());
            ps.setInt(2, room.getSeats());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }

    public static void dropRoom(RoomEntry room) throws Exception {
        try {
            Connection connection = DBConnection.getConnection();
            PreparedStatement ps = connection.prepareStatement("DELETE FROM room WHERE name= ?");
            ps.setString(1, room.getName());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
    }
}
