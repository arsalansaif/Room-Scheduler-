package forms.tablemodel;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.ReservationEntry;
import model.WaitlistEntry;

public class TableModelFacultyMember extends AbstractTableModel {

    private List<ReservationEntry> listRes;
    private List<WaitlistEntry> listWait;
    private String[] headers;

    public TableModelFacultyMember(List<ReservationEntry> listRes, List<WaitlistEntry> listWait) {
        this.listRes = listRes;
        this.listWait = listWait;
        this.headers = new String[]{"Room", "Date"};
    }

    @Override
    public int getRowCount() {
        return listRes.size() + listWait.size();
    }

    @Override
    public int getColumnCount() {
        return headers.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        if (rowIndex < listRes.size()) {
            ReservationEntry row = listRes.get(rowIndex);
            switch (columnIndex) {
                case 0:
                    return row.getRoom();
                case 1:
                    return row.getDate();
                default:
                    return "N/A";
            }
        } else {
            WaitlistEntry row = listWait.get(rowIndex - listRes.size());
            switch (columnIndex) {
                case 0:
                    return "Waitlist";
                case 1:
                    return row.getDate();
                default:
                    return "N/A";
            }
        }
    }

    @Override
    public String getColumnName(int column) {
        return headers[column];
    }
}
