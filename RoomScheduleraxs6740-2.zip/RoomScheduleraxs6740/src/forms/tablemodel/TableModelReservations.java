package forms.tablemodel;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.ReservationEntry;

public class TableModelReservations extends AbstractTableModel {

    private List<ReservationEntry> list;
    private String[] headers;

    public TableModelReservations(List<ReservationEntry> list) {
        this.list = list;
        this.headers = new String[]{"Faculty", "Room", "Seats"};
    }

    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return headers.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        ReservationEntry row = list.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return row.getFaculty();
            case 1:
                return row.getRoom();
            case 2:
                return row.getSeats();
            default:
                return "N/A";
        }
    }

    @Override
    public String getColumnName(int column) {
        return headers[column];
    }

    public ReservationEntry getRow(int row) {
        return list.get(row);
    }

}
