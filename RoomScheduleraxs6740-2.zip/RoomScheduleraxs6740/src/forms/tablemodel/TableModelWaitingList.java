package forms.tablemodel;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.WaitlistEntry;

public class TableModelWaitingList extends AbstractTableModel {

    private List<WaitlistEntry> list;
    private String[] headers;

    public TableModelWaitingList(List<WaitlistEntry> list) {
        this.list = list;
        this.headers = new String[]{"Faculty", "Seats", "Date", "TimeStamp"};
    }

    @Override
    public int getRowCount() {
        return list.size();
    }

    @Override
    public int getColumnCount() {
        return headers.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        WaitlistEntry row = list.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return row.getFaculty();
            case 1:
                return row.getSeats();
            case 2:
                return row.getDate();
            case 3:
                return row.getTimestamp();
            default:
                return "N/A";
        }
    }

    @Override
    public String getColumnName(int column) {
        return headers[column];
    }

    public WaitlistEntry getRow(int row) {
        return list.get(row);
    }

}
